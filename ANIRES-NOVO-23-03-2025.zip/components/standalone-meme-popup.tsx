"use client"

// Este componente foi desativado para evitar popups duplicados
export default function StandaloneMemePopup() {
  // Retorna null para não renderizar nada
  return null
}

