# Anires Airdrop

Aplicação para reclamar tokens $ANIRES através de airdrop.

## Requisitos

- Node.js 18 ou superior
- npm ou yarn

## Configuração

1. Clone o repositório
2. Instale as dependências:

```bash
npm install

